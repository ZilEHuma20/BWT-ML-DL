from mymath import add, subtract, multiply, divide, mod, exponentiate, square_root

def main():
    # Basic arithmetic operations
    print(f"Addition: 5 + 3 = {add(5, 3)}")
    print(f"Subtraction: 5 - 3 = {subtract(5, 3)}")
    print(f"Multiplication: 5 * 3 = {multiply(5, 3)}")
    print(f"Division: 5 / 3 = {divide(5, 3)}")
    print(f"Modulus: 5 % 3 = {mod(5, 3)}")
    
    # Advanced mathematical operations
    print(f"Exponentiation: 2 ** 3 = {exponentiate(2, 3)}")
    print(f"Square Root: sqrt(16) = {square_root(16)}")

if __name__ == "__main__":
    main()
