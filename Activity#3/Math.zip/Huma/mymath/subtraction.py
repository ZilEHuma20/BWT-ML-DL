def subtract(a, b):
    return a - b
