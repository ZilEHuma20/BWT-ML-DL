def mod(a, b):
    return a % b
